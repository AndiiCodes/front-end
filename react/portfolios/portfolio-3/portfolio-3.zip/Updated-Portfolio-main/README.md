#New portfolio showcasing all my projects and skills created with React and additional JS libraries!
https://akshayv.tech/
Dynamic and responsive design, soon incorporating different APIs, and animations

![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/52a6feec-6cf4-49e1-9b5c-ab6618fd3068)


![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/a6bd4ae2-1bb4-43aa-b1c6-82e6706155f7)

![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/f38e0420-18f6-4537-9ee4-78294c8db92e)

![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/c639575d-c4b6-4faf-8930-e4c75d0b06f6)

![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/284f8261-8731-4380-b204-9e231fb76b2e)
![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/77cd4674-c86c-4ce9-87b4-bbb18bb7aaa5)
![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/e75424ac-2673-4100-82e3-c6727dbf0193)


![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/813d5852-872e-433b-a744-431d7f38caff)
![image](https://github.com/Octrainn/Updated-Portfolio/assets/117962555/33d985c1-0eb6-4c5a-834d-ff215d363681)



