
import AOS from 'aos'
import './CSS Files/animation.css'
 